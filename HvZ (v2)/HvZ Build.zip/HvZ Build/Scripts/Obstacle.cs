﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Youki Iimori
/// This class simply gives each obstacle a radius
/// </summary>
public class Obstacle : MonoBehaviour {

    // Use this for initialization
    public float radius = .5f;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
